Ryan Donovan McCauley
UIN: 727009447
Section 501

NOTE:

I made the assumption that for fibonacci
the first number in the sequence is 0 and
then it moves normally from there.

0  -> 1st
1  -> 2nd
1  -> 3rd
2  -> 4th
3  -> 5th
5  -> 6th
8  -> 7th
13 -> 8th
...

So when asked for f(6) the answer is 5.